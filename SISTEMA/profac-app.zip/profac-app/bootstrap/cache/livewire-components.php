<?php return array (
  'bodega' => 'App\\Http\\Livewire\\Bodega',
  'bodega-component.bodega-editar' => 'App\\Http\\Livewire\\BodegaComponent\\BodegaEditar',
  'bodega-component.bodega-gestiones' => 'App\\Http\\Livewire\\BodegaComponent\\BodegaGestiones',
  'inventario.compra-producto' => 'App\\Http\\Livewire\\Inventario\\CompraProducto',
  'inventario.detalle-producto' => 'App\\Http\\Livewire\\Inventario\\DetalleProducto',
  'inventario.producto' => 'App\\Http\\Livewire\\Inventario\\Producto',
  'inventario.retenciones' => 'App\\Http\\Livewire\\Inventario\\Retenciones',
  'proveedores' => 'App\\Http\\Livewire\\Proveedores',
  'usuarios.listar-usuarios' => 'App\\Http\\Livewire\\Usuarios\\ListarUsuarios',
);