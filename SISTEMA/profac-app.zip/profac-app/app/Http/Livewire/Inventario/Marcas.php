<?php

namespace App\Http\Livewire\Inventario;

use Livewire\Component;

class Marcas extends Component
{
    public function render()
    {
        return view('livewire.inventario.marcas');
    }
}
