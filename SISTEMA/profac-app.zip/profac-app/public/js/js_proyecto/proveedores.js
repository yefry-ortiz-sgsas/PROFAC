// $('#bodegaCreacion').submit(function(e){
//     console.log(e)
//     e.preventDefault();
//     crearBodega();
// });



// $(function () {
//     $('#bodegaCreacion').parsley().on('field:validated', function() {

//       var ok = $('.parsley-error').length === 0;
//       $('.bs-callout-info').toggleClass('hidden', !ok);
//       $('.bs-callout-warning').toggleClass('hidden', ok);
//     })

//     .on('form:submit', function() {
//       return false; // Don't submit form for this demo
//     });
//   });

//console.log("llega el js");

