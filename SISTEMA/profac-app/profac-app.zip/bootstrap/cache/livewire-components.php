<?php return array (
  'bodega' => 'App\\Http\\Livewire\\Bodega',
  'bodega-component.bodega-editar' => 'App\\Http\\Livewire\\BodegaComponent\\BodegaEditar',
  'bodega-component.bodega-gestiones' => 'App\\Http\\Livewire\\BodegaComponent\\BodegaGestiones',
  'proveedores' => 'App\\Http\\Livewire\\Proveedores',
  'usuarios.listar-usuarios' => 'App\\Http\\Livewire\\Usuarios\\ListarUsuarios',
);