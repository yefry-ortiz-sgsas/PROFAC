<?php

namespace App\Http\Livewire\Ventas;

use Livewire\Component;

class ListarVale extends Component
{
    public function render()
    {
        return view('livewire.ventas.listar-vale');
    }
}
