<?php

namespace App\Http\Livewire\VentasEstatal;

use Livewire\Component;

class SinRestriccionGobierno extends Component
{
    public function render()
    {
        return view('livewire.ventas-estatal.sin-restriccion-gobierno');
    }
}
