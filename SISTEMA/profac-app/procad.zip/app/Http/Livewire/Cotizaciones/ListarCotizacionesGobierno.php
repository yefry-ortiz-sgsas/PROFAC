<?php

namespace App\Http\Livewire\Cotizaciones;

use Livewire\Component;

class ListarCotizacionesGobierno extends Component
{
    public function render()
    {
        return view('livewire.cotizaciones.listar-cotizaciones-gobierno');
    }
}
