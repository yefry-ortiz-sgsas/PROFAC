<?php

namespace App\Models\ventas;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NumOrdenCompra extends Model
{
    use HasFactory;
}
